Graph datasets in csv format.
Used in the article Learning Functional Causal Models with Generative Neural Networks. Olivier Goudet - Diviyan Kalainathan - Aris Tritas - Philippe Caillou - Paola Tubaro - Isabelle Guyon - Mich�le S�bag

Each file *_numdata.csv contain the data of around 20 variables connected in a graph without hidden variables.
G2, G3, G4 and G5 refered to graph with 2, 3, 4 and 5 parents maximum for each node.
Each file *_target.csv contains the ground truth of the graph with cause -> effect
